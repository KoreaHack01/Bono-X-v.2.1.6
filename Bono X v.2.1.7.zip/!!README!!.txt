@@@@@English Version@@@@
Bono X v.2.1.6

Welcome to Bono X! The Best script executer!!
We Updated to level 7!! Using the Ex,KRNL API!!


Do not share the key to anyone!!!
Eh.. even to your mom duh :P

So.. Let's start some tutorials


-------------------------Buttons------------------------------
Execute : Executes the script.
Clear : Clear the textbox.
Open File : Open a file to textbox.
Save File : Save a file.
Script Hub : Many scripts are waing for you. 
Options : Show you Options Tap
Refresh : Refresh the scripts in the <\Bono X v.2.1.6\Scripts>  Folder
Inject : Inject Bono X to Roblox
-----------------------Buttons End-----------------------------


Bono X is the Best exploit!!!!


-----------------------Options------------------------------------
#Credits Tab
 -Just a credits tab who made this exploit.
 @T.M.I = KH_Offical was my first youtube channel but it's banned STF

#Settings Tab
 -Top Most : If it's true,Bono X will be showing of the top of the screen
 -Show In Taskbar : If it's true, Bono X will be show in Taskbar
 -Dark/White : The Theme color changing.
 -TextColor Dark / White : If it's true, the textcolor of textbox is white. when false? Black.
 - Use Theme : If you continue, when you wanna don't use the theme, 
 You have to restart the Exploit.
 -Simple UI : Shows you a simple UI
 -Update : When you continue, It will download the file.

 -Theme Using tutorial-
 @@1. Goto the folder named <\Bono X v.2.1.6\Theme/Textbox>
 @@2. You can see the jpg file named Background.jpg
 @@3. You have to have some image file with .jpg
 @@4. The size of the image must be 666, 327
 @@5. Rename it "Background.jpg" and use the theme!!
 -Theme Tutorial End

 File name is <\Bono X\XDOWNLOAD> There are folder and the zipfile
#API Tab
 -EasyExploits / KRNL : You can choose the API in here! / Ex = lv.6 , KRNL = lv.7
 - Open Bypass link bla...bla... :
 If it's true, When you inject the KRNL API, It Opens a key bypass link.


----------------------------Options End--------------------


This is end of tutorial!
Enjoy the Best experience!!

Supprot us?
Just enjoy the Exploit!!
Thank you for using Bono X!

Sincerely Bono X™

©Copyright All rights reserved to 2020-2021 Dev Mang_Tang 


########################################################################


@@@@한글 버전@@@@ 
*!!한글 버전은 번역이 완전하지 않을 수 있습니다!!*
o(*￣▽￣*)ブ        한글 번역 : 망탱이

Bono X v.2.1.6

Bono X에 오신 것을 환영합니다! 최고의 로블록스 핵!!
레벨 7로 업데이트했습니다 !! Ex, KRNL API 사용합니다 !!

누구에게도 키를 공유하지 마십시오 !!!
음... 엄마한테도요 :P

그래서 .. 몇 가지 튜토리얼을 시작하겠습니다


##################################
------------------------- 버튼 ------------------------ ------
#################################


Execute : 스크립트를 실행합니다.
Clear : 텍스트 상자를 초기화시킵니다.
Open File : 파일을 엽니다.
Save File : 파일을 저장합니다.
Script Hub : 많은 스크립트가 당신을 기다리고 있습니다.
Options : 옵션 탭 표시
Refresh : <\ Bono X v.2.1.6 \ Scripts> 폴더의 스크립트를 새로고칩니다.
Inject: Bono X를 인젝합니다
----------------------- 버튼 끝 ------------------------- ----


#######################################
Bono X는 최고의 로블록스 핵입니다 !!!!
#####################################


----------------------- 옵션 ------------------------- ----------
######################################
# Credits 탭
 -이 핵을 만든 사람들의 크레딧입니다.
 @ T.M.I = KH_Offical은 내 첫 유튜브 채널 이었지만 영정당했습니다.
# Settings 탭

 -Top Most : 켜면 Bono X가 화면 상단에 표시됩니다.
 -Show In Taskbar : 켜면면 Bono X가 작업 표시 줄에 표시됩니다.
 -Dark / White : 테마 색상이 변경됩니다.
 -TextColor Dark / White : 켜면 글자색은 하얀색이 되고 끄면 글자색은 검정색이 됩니다.
 -Use Theme : 계속하면 테마를 사용하지 않을 때
 핵을 다시 시작해야합니다.
 -Simple UI : 더욱더 심플한 UI를 제공합니다
 -Update : 계속하면 파일을 다운로드합니다.

 -테마 사진 튜토리얼-
 @@1. <\ Bono X v.2.1.6 \ Theme / Textbox>라는 폴더로 이동합니다.
 @@ 2. Background.jpg라는 jpg 파일이 있어야 합니다.
 @@3. 확장자 .jpg가 포함 된 이미지 파일이 있어야합니다.
 @@ 4. 이미지 크기는 666, 327이어야합니다.
 @@ 5. "Background.jpg"로 이름을 바꾸고 테마를 사용하세요 !!
 -테마 튜토리얼 끝-

 파일명은 <\ Bono X \ XDOWNLOAD> 에폴더와 zip 파일이 다운받아져 있습니다.
#API 탭
 -EasyExploits / KRNL : 여기에서 API를 선택할 수 있습니다! / 레벨들 = lv.6, KRNL = lv.7
 -Open Bypass link b 어쩌구... 저쩌구... :
 켜면 KRNL API를 주입하면 키 우회 링크가 열립니다.


###########################################
---------------------------- 옵션 종료 --------------------
###############################################


이것으로 튜토리얼이 끝났습니다!
최고의 경험을 즐기십시오 !!

우리를 후원하고 싶으시다면?
그냥 핵을 즐기세요 !!
Bono X를 사용해 주셔서 감사합니다!

감사합니다 Bono X ™

©Copyright All rights reserved to 2020-2021 Dev Mang_Tang 